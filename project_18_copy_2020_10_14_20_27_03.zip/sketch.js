var backgroun, back_Image
var monkey, monkey_Running;
var ground, bananaGroup
var obstacleGroup, obstacle_Image, banana_Image
var score;
var gameState = 1;
var END = 0;
var PLAY = 1;

function preload() { 
  back_Image = loadImage("jungle.jpg");
  monkey_Running = loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  obstacle_Image = loadImage("stone.png");
  banana_Image = loadImage("banana.png");
  }
function setup() {
  createCanvas(400, 400);
  backgroun = createSprite(200,200,400,400);
  backgroun.addImage (back_Image);
  backgroun.x = backgroun.width/2;
  backgroun.velocityX = -4;
  
  monkey = createSprite(80,260,20,50);
 monkey.addAnimation("running",monkey_Running);
  monkey.scale = 0.1;
  
  score = 0;
  
  ground = createSprite (200,390,400,10);
  ground.visible = false;
  
  bananaGroup = new Group();
  obstacleGroup = new Group();
}
function draw() {
  text ("score" +  score,50,50);
  if(backgroun.x < 0){
   backgroun.x = 200;
  }
  if (gameState === PLAY){
    if (keyDown("space") && monkey.y >= 230){
    monkey.velocityY = -9;
  }
  monkey.velocityY = monkey.velocityY+ 0.4;
 
  food();
    if (bananaGroup.isTouching(monkey)){
   bananaGroup.destroyEach();
    score = score+1;
  }
  obstacles();
    if (obstacleGroup.isTouching(monkey)){
  gameState = END;
  bananaGroup.destroyEach();
 obstacleGroup.destroyEach(); 
  }
  }else if (gameState === END){
    backgroun.velocityX = 0;
    backgroun.X = 200;
    monkey.visible = false;
    text ("gameover",200,200);
    text ("press space to restart",200,240);
    if (keyDown("space")){
      monkey.visible = true;
      backgroun.velocityX = -4;
      reset();
    }
  }
  monkey.collide(ground);
  drawSprites();
}
function reset(){
  gameState = PLAY;
  score = 0;
}
function food(){
  if (frameCount % 80 === 0){
    var banana = createSprite(400,200,20,20);
    banana.addImage(banana_Image);
    banana.scale = 0.05;
    banana.y = Math.round(random(110,190));
    banana.lifetime = 50;
    banana.velocityX = -7;
    bananaGroup.add(banana);
  }
}
function obstacles(){
  if (frameCount % 300 === 0){
    var obstacle = createSprite(400,200,20,20);
    obstacle.addImage(obstacle_Image);
    obstacle.scale = 0.25;
    obstacle.y = 360;
    obstacle.lifetime = 70;
    obstacle.velocityX = -7;
    obstacleGroup.add(obstacle);
  }
}